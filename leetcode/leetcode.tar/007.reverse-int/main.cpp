#include "Solution.h"
#include <iostream>
#include <vector>
#include <limits>
using namespace std;

int main()
{
    Solution su;
    su.reverse(-123);
    su.reverse(-3456787654567);
    su.reverse(1323);
    return 0;
}
