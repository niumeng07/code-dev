#include "Solution.h"
#include <iostream>
#include <vector>
#include <limits>
using namespace std;

int main()
{
    Solution su;/*
    cout << su.myAtoi("  +2147483648  ")<< endl;
    cout << su.myAtoi("+")<< endl;
    cout << su.myAtoi("+010")<< endl;
    cout << su.myAtoi("  -2147483648  ")<< endl;
    cout << su.myAtoi("  2147483649")<< endl;
    cout << su.myAtoi("--15459")<< endl;
    cout << su.myAtoi("--15ldf459")<< endl;
    */
    cout << su.myAtoi("")<< endl;
    return 0;
}
